# Kasuskonsole v29 QA report

## Scope

This pass addressed red-flag quality issues, not new product features:

- Broken UTF-8/mojibake text across German, Turkish, Arabic, Chinese, and Ukrainian UI strings.
- Setup/options scroll behavior that could trap the page inside the console shell.
- Roadmap/"To come" accuracy in the menu.
- Continued responsive UX checks across representative phone, landscape, laptop, and desktop states.

## Checks run

| Check | Result |
|---|---|
| JavaScript syntax extraction from `index.html` | Pass: 1 script parsed |
| Encoding smoke check | Pass: no common mojibake code points detected after repair |
| Chrome DevTools runtime/log events during QA states | Pass: 0 events recorded |
| Scroll reachability | Pass: every tested primary scroll container reached top and bottom |
| Screenshot generation | Pass: 10 after screenshots generated |

## Scroll QA

| State | Viewport | Primary scroller | Top reachable | Bottom reachable | Scroll range |
|---|---:|---|---|---|---:|
| setup expanded, top | 390x844 | document | pass | pass | 585 |
| setup expanded, bottom | 390x844 | document | pass | pass | 585 |
| setup default | 320x568 | document | pass | pass | 306 |
| menu open | 430x932 | `#settingsPanel` | pass | pass | 412 |
| Genitive help | 390x844 | `.genitiveHelpCard` | pass | pass | 0 |
| cloze wrong feedback | 390x844 | `main` | pass | pass | 0 |
| table wrong feedback | 932x430 | `main` | pass | pass | 80 |
| results | 1440x900 | `main` | pass | pass | 77 |
| Arabic cloze | 390x844 | `main` | pass | pass | 0 |
| setup expanded, short laptop | 1365x599 | document | pass | pass | 70 |

Raw data: `SCROLL_QA.json`.

## Screenshots

- `screenshots/320x568-setup-default.png`
- `screenshots/390x844-setup-expanded-top.png`
- `screenshots/390x844-setup-expanded-bottom.png`
- `screenshots/430x932-menu-open.png`
- `screenshots/390x844-genitive-help.png`
- `screenshots/390x844-cloze-wrong.png`
- `screenshots/932x430-table-wrong.png`
- `screenshots/1440x900-results.png`
- `screenshots/390x844-arabic-cloze.png`
- `screenshots/1365x599-setup-expanded.png`

## Known limitations

- This is still a single-file prototype with accumulated CSS patches. The v29 work avoids a rebuild, but a future maintainability pass should consolidate duplicate responsive rules.
- The scroll test verifies top/bottom reachability and stability after programmatic scroll. It cannot physically simulate iOS rubber-band physics, but removing setup's nested scroll container addresses the known class of issue.

