const fs = require("fs");
const path = require("path");
const http = require("http");
const childProcess = require("child_process");

const root = __dirname;
const outDir = path.join(root, "screenshots");
const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const serverPort = 8792;
const cdpPort = 9232;

fs.mkdirSync(outDir, { recursive: true });

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function startServer() {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://127.0.0.1:${serverPort}`);
    const filePath = path.join(root, url.pathname === "/" ? "index.html" : url.pathname);
    fs.readFile(filePath, (err, data) => {
      if (err) {
        res.writeHead(404, { "content-type": "text/plain" });
        res.end("not found");
        return;
      }
      const ext = path.extname(filePath).toLowerCase();
      const type = ext === ".html" ? "text/html; charset=utf-8" : ext === ".png" ? "image/png" : "application/octet-stream";
      res.writeHead(200, { "content-type": type, "cache-control": "no-store" });
      res.end(data);
    });
  });
  return new Promise(resolve => server.listen(serverPort, "127.0.0.1", () => resolve(server)));
}

function startChrome() {
  const profile = path.join(outDir, "cdp-profile");
  fs.rmSync(profile, { recursive: true, force: true });
  return childProcess.spawn(chromePath, [
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--force-device-scale-factor=1",
    `--remote-debugging-port=${cdpPort}`,
    `--user-data-dir=${profile}`,
    "--window-size=1200,900",
    "about:blank"
  ], { stdio: "ignore" });
}

async function waitForJson(url, timeoutMs = 10000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const response = await fetch(url);
      if (response.ok) return await response.json();
    } catch (e) {}
    await delay(150);
  }
  throw new Error(`Timed out waiting for ${url}`);
}

async function createPage() {
  const target = await fetch(`http://127.0.0.1:${cdpPort}/json/new?about:blank`, { method: "PUT" }).then(r => r.json());
  return connectCdp(target.webSocketDebuggerUrl);
}

function connectCdp(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    const pending = new Map();
    let id = 0;
    const events = [];
    ws.onopen = () => {
      resolve({
        events,
        send(method, params = {}) {
          return new Promise((res, rej) => {
            const messageId = ++id;
            pending.set(messageId, { res, rej, method });
            ws.send(JSON.stringify({ id: messageId, method, params }));
          });
        },
        close() {
          ws.close();
        }
      });
    };
    ws.onerror = reject;
    ws.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.id && pending.has(message.id)) {
        const item = pending.get(message.id);
        pending.delete(message.id);
        if (message.error) item.rej(new Error(`${item.method}: ${message.error.message}`));
        else item.res(message.result || {});
      } else if (message.method) {
        events.push(message);
      }
    };
  });
}

async function evalPage(cdp, expression) {
  const result = await cdp.send("Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true
  });
  if (result.exceptionDetails) {
    throw new Error(result.exceptionDetails.text || "Runtime.evaluate failed");
  }
  return result.result ? result.result.value : undefined;
}

async function gotoState(cdp, width, height, state) {
  await cdp.send("Emulation.setDeviceMetricsOverride", {
    width,
    height,
    deviceScaleFactor: 1,
    mobile: width <= 430,
    screenWidth: width,
    screenHeight: height
  });
  await cdp.send("Page.navigate", { url: `http://127.0.0.1:${serverPort}/index.html?v=${Date.now()}-${state}` });
  await delay(900);
  await evalPage(cdp, `new Promise(resolve => {
    const done = () => resolve(document.readyState);
    if (document.readyState === "complete") done();
    else window.addEventListener("load", done, { once:true });
  })`);
  await evalPage(cdp, `new Promise(async resolve => {
    const wait = ms => new Promise(r => setTimeout(r, ms));
    function click(sel) {
      const el = document.querySelector(sel);
      if (el) el.dispatchEvent(new MouseEvent("click", { bubbles:true, cancelable:true, view:window }));
    }
    function setValue(sel, value) {
      const el = document.querySelector(sel);
      if (!el) return;
      el.value = value;
      el.dispatchEvent(new Event("change", { bubbles:true }));
    }
    for (let i = 0; i < 80 && typeof window.kasusStartRound !== "function"; i++) await wait(50);
    try { localStorage.clear(); } catch (e) {}
    if (${JSON.stringify(state)} === "setupExpanded") {
      document.querySelectorAll(".startAccordion").forEach(el => el.open = true);
    }
    if (${JSON.stringify(state)} === "menuOpen") {
      click("#menuToggle");
    }
    if (${JSON.stringify(state)} === "genitiveHelp") {
      const gen = document.querySelector("#genitiveAccordion");
      if (gen) gen.open = true;
      click("#startGenitiveHelpBtn");
    }
    if (${JSON.stringify(state)} === "arabicCloze") {
      click('[data-lang="ar"]');
      await wait(80);
      setValue("#startTaskType", "cloze");
      click("#startRoundBtn");
    }
    if (${JSON.stringify(state)} === "tablePrompt" || ${JSON.stringify(state)} === "tableWrong") {
      setValue("#startTaskType", "table");
      click("#startRoundBtn");
      await wait(120);
      if (${JSON.stringify(state)} === "tableWrong") {
        const input = document.querySelector("#answerInput");
        if (input) input.value = "zzz";
        window.kasusCheck();
      }
    }
    if (${JSON.stringify(state)} === "clozePrompt" || ${JSON.stringify(state)} === "clozeWrong") {
      setValue("#startTaskType", "cloze");
      click("#startRoundBtn");
      await wait(120);
      if (${JSON.stringify(state)} === "clozeWrong") {
        const input = document.querySelector("#answerInput");
        if (input) input.value = "zzz";
        window.kasusCheck();
      }
    }
    if (${JSON.stringify(state)} === "results") {
      setValue("#startTaskType", "mixed");
      setValue("#startRoundTarget", "10");
      click("#startRoundBtn");
      await wait(120);
      for (let i = 0; i < 14 && !document.body.classList.contains("resultsMode"); i++) {
        const cur = window.kasusCurrent && window.kasusCurrent();
        if (!cur) break;
        if (cur.correctAnswer === "none") window.kasusNoArticle();
        else {
          const input = document.querySelector("#answerInput");
          if (input) input.value = cur.correctAnswer;
          window.kasusCheck();
        }
        await wait(40);
        window.kasusProceed();
        await wait(40);
      }
    }
    await wait(220);
    resolve(true);
  })`);
}

async function measureScroll(cdp, selector) {
  return evalPage(cdp, `new Promise(async resolve => {
    const wait = ms => new Promise(r => setTimeout(r, ms));
    const el = ${selector === "document" ? "document.scrollingElement" : `document.querySelector(${JSON.stringify(selector)})`};
    if (!el) {
      resolve({ selector:${JSON.stringify(selector)}, exists:false });
      return;
    }
    const max = Math.max(0, el.scrollHeight - el.clientHeight);
    el.scrollTop = 0;
    await wait(80);
    const top = el.scrollTop;
    el.scrollTop = max;
    await wait(100);
    const bottom = el.scrollTop;
    el.scrollTop = 0;
    await wait(80);
    const topAgain = el.scrollTop;
    resolve({
      selector:${JSON.stringify(selector)},
      exists:true,
      scrollHeight:el.scrollHeight,
      clientHeight:el.clientHeight,
      max,
      top,
      bottom,
      topAgain,
      reachesTop:top <= 2 && topAgain <= 2,
      reachesBottom:max <= 2 || bottom >= max - 3
    });
  })`);
}

async function screenshot(cdp, name) {
  const result = await cdp.send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
  fs.writeFileSync(path.join(outDir, `${name}.png`), Buffer.from(result.data, "base64"));
}

async function scrollToEnd(cdp, selector) {
  await evalPage(cdp, `(() => {
    const el = ${selector === "document" ? "document.scrollingElement" : `document.querySelector(${JSON.stringify(selector)})`};
    if (!el) return false;
    el.scrollTop = Math.max(0, el.scrollHeight - el.clientHeight);
    return true;
  })()`);
  await delay(120);
}

async function main() {
  const server = await startServer();
  const chrome = startChrome();
  try {
    await waitForJson(`http://127.0.0.1:${cdpPort}/json/version`);
    const cdp = await createPage();
    await cdp.send("Page.enable");
    await cdp.send("Runtime.enable");
    const cases = [
      { name:"390x844-setup-expanded-top", width:390, height:844, state:"setupExpanded", primary:"document", shot:true },
      { name:"390x844-setup-expanded-bottom", width:390, height:844, state:"setupExpanded", primary:"document", shot:true, shotScroll:"bottom" },
      { name:"320x568-setup-default", width:320, height:568, state:"setupDefault", primary:"document", shot:true },
      { name:"430x932-menu-open", width:430, height:932, state:"menuOpen", primary:"#settingsPanel", shot:true },
      { name:"390x844-genitive-help", width:390, height:844, state:"genitiveHelp", primary:".genitiveHelpCard", shot:true },
      { name:"390x844-cloze-wrong", width:390, height:844, state:"clozeWrong", primary:"main", shot:true },
      { name:"932x430-table-wrong", width:932, height:430, state:"tableWrong", primary:"main", shot:true },
      { name:"1440x900-results", width:1440, height:900, state:"results", primary:"main", shot:true },
      { name:"390x844-arabic-cloze", width:390, height:844, state:"arabicCloze", primary:"main", shot:true },
      { name:"1365x599-setup-expanded", width:1365, height:599, state:"setupExpanded", primary:"document", shot:true }
    ];
    const report = [];
    for (const item of cases) {
      await gotoState(cdp, item.width, item.height, item.state);
      const primary = await measureScroll(cdp, item.primary);
      const documentScroll = await measureScroll(cdp, "document");
      const mainScroll = await measureScroll(cdp, "main");
      const errors = cdp.events.filter(e => e.method === "Runtime.exceptionThrown" || e.method === "Log.entryAdded").length;
      if (item.shotScroll === "bottom") await scrollToEnd(cdp, item.primary);
      if (item.shot) await screenshot(cdp, item.name);
      report.push({ ...item, primary, documentScroll, mainScroll, runtimeOrLogEvents: errors });
    }
    fs.writeFileSync(path.join(root, "SCROLL_QA.json"), JSON.stringify(report, null, 2), "utf8");
    cdp.close();
    console.log(JSON.stringify(report.map(item => ({
      name:item.name,
      primary:item.primary.selector,
      reachesTop:item.primary.reachesTop,
      reachesBottom:item.primary.reachesBottom,
      max:item.primary.max,
      shot:`screenshots/${item.name}.png`
    })), null, 2));
  } finally {
    server.close();
    chrome.kill();
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
