## v29 - UX polish, encoding, and scroll fixes

- Repaired mojibake/UTF-8 text corruption across German UI, support-language labels, prompts, explanations, and translations.
- Changed setup/options scrolling to document-level scrolling so the options screen can reach both top and bottom without trapped nested-scroll bounce.
- Preserved practice-screen internal scrolling where the fixed HUD needs a bounded console surface.
- Added scroll containment and touch scrolling behavior for menu, modal, and console scroll containers.
- Updated the menu "To come" roadmap list to match the most useful next feature directions.
- Renamed the stale page title to `Kasuskonsole`.
- Verified setup, menu, Genitive help, cloze/table feedback, Arabic mode, and results scroll reachability.

