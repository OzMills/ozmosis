# Kasuskonsole v29 UX notes

## UX principles applied

- Legibility before decoration: fixing the encoding bug restores the core learning object. A trainer cannot rely on recall if the cue itself is visually corrupted.
- Fitts's Law: large primary controls remain close to the task flow; no new distant actions were introduced.
- Cognitive load: no new option groups were added to the setup screen. The roadmap list was updated in the menu, where it does not interfere with practice.
- Progressive disclosure: advanced Genitive/support controls remain behind accordions.
- Scroll containment: setup now scrolls at the document level because it has no fixed HUD. Practice screens keep their internal console scroll because the HUD is fixed there.
- Directionality: German prompts, answer fields, tables, and article forms remain LTR even when support language is Arabic.
- Error recovery: wrong feedback remains concise and visually separates wrong attempt from correct answer.

## Product/roadmap cleanup

The menu "To come" list now reflects the most useful next additions:

- Focused repair mode
- Contrast drills for DER/EIN/KEIN neighbor forms
- Possessive articles
- Adjective endings
- Error-type session insights
- Custom cloze import

These are roadmap labels only. v29 does not implement new practice modes or grammar content.

